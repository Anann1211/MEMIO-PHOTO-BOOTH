'use client'
import { useRef, useEffect, useState, useCallback } from 'react'
import { useBoothStore } from '@/store/boothStore'
import toast from 'react-hot-toast'

export function WebcamCapture({ onCapture }: { onCapture: (url: string) => void }) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const [status, setStatus] = useState<'idle'|'loading'|'ready'|'error'|'counting'>('idle')
  const [count, setCount] = useState(0)
  const [flash, setFlash] = useState(false)
  const { settings } = useBoothStore()

  useEffect(() => { startCamera(); return () => streamRef.current?.getTracks().forEach(t=>t.stop()) }, [])

  async function startCamera() {
    setStatus('loading')
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video:{ width:{ideal:1280},height:{ideal:720},facingMode:'user' }, audio:false })
      streamRef.current = stream
      if (videoRef.current) { videoRef.current.srcObject = stream; videoRef.current.onloadedmetadata = () => setStatus('ready') }
    } catch { setStatus('error'); toast.error('Không thể truy cập webcam') }
  }

  const capture = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return
    const v = videoRef.current, c = canvasRef.current
    c.width = v.videoWidth; c.height = v.videoHeight
    const ctx = c.getContext('2d')!
    if (settings.mirror_enabled) { ctx.translate(c.width,0); ctx.scale(-1,1) }
    ctx.drawImage(v,0,0)
    if (settings.flash_enabled) { setFlash(true); setTimeout(()=>setFlash(false),400) }
    onCapture(c.toDataURL('image/jpeg',0.95))
  }, [settings, onCapture])

  const startCountdown = useCallback(() => {
    if (status !== 'ready') return
    setStatus('counting'); let c = settings.countdown; setCount(c)
    const iv = setInterval(() => {
      c--; if (c<=0) { clearInterval(iv); setStatus('ready'); setCount(0); capture() } else setCount(c)
    }, 1000)
  }, [status, settings.countdown, capture])

  if (status === 'error') return (
    <div className="card-kawaii p-8 text-center">
      <div className="text-5xl mb-4">📷</div>
      <h3 className="font-display font-bold text-lg text-memio-brown dark:text-white mb-2">Không thể truy cập webcam</h3>
      <p className="font-body text-sm text-memio-brown-light mb-6">Vui lòng cho phép truy cập camera trong trình duyệt</p>
      <div className="flex gap-3 justify-center flex-wrap">
        <button className="btn-primary" onClick={startCamera}>🔄 Thử lại</button>
        <label className="btn-secondary cursor-pointer">
          📁 Upload ảnh thay thế
          <input type="file" accept="image/*" className="hidden" onChange={e=>{
            const f=e.target.files?.[0]; if(!f) return
            const r=new FileReader(); r.onload=ev=>onCapture(ev.target?.result as string); r.readAsDataURL(f)
          }} />
        </label>
      </div>
    </div>
  )

  return (
    <div className="relative">
      {flash && <div className="flash-overlay"/>}
      <div className="relative rounded-card overflow-hidden shadow-kawaii-lg bg-black">
        <video ref={videoRef} autoPlay playsInline muted className={`w-full aspect-video object-cover ${settings.mirror_enabled?'scale-x-[-1]':''}`} />
        <canvas ref={canvasRef} className="hidden" />
        {status==='loading' && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center gap-3">
            <div className="w-8 h-8 rounded-full border-4 border-memio-pink border-t-transparent animate-spin"/>
            <span className="font-body text-white text-sm">Đang khởi động camera...</span>
          </div>
        )}
        {status==='counting' && count>0 && (
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
            <span className="countdown-number" key={count}>{count}</span>
          </div>
        )}
      </div>
      <div className="flex items-center justify-center gap-4 mt-6">
        <button onClick={startCountdown} disabled={status!=='ready'} className="btn-primary px-10 py-4 text-lg disabled:opacity-50">
          {status==='counting' ? `${count}...` : '📸 Chụp ảnh'}
        </button>
        <button onClick={capture} disabled={status!=='ready'} className="btn-ghost py-4 px-6 text-sm disabled:opacity-50">
          Chụp ngay
        </button>
      </div>
    </div>
  )
}

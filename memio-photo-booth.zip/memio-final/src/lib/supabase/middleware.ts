import { createServerClient } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'
export async function updateSession(request: NextRequest) {
  let response = NextResponse.next({ request })
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() { return request.cookies.getAll() },
        setAll(list) {
          list.forEach(({name,value}) => request.cookies.set(name,value))
          response = NextResponse.next({ request })
          list.forEach(({name,value,options}) => response.cookies.set(name,value,options))
        },
      },
    }
  )
  const { data:{ user } } = await supabase.auth.getUser()
  const path = request.nextUrl.pathname
  const protected_ = ['/booth','/gallery','/profile','/admin']
  const authPages = ['/auth/dang-nhap','/auth/dang-ky']
  if (protected_.some(r => path.startsWith(r)) && !user)
    return NextResponse.redirect(new URL('/auth/dang-nhap', request.url))
  if (authPages.some(r => path.startsWith(r)) && user)
    return NextResponse.redirect(new URL('/booth/chon-template', request.url))
  return response
}

const BASE = 'https://api.replicate.com/v1/predictions'
async function run(version: string, input: Record<string,unknown>): Promise<string> {
  const res = await fetch(BASE, {
    method:'POST',
    headers:{ 'Authorization':`Token ${process.env.REPLICATE_API_TOKEN}`, 'Content-Type':'application/json' },
    body: JSON.stringify({ version, input }),
  })
  if (!res.ok) throw new Error('Replicate error')
  let p = await res.json()
  while (p.status !== 'succeeded' && p.status !== 'failed') {
    await new Promise(r => setTimeout(r, 1500))
    p = await (await fetch(`${BASE}/${p.id}`, { headers:{ 'Authorization':`Token ${process.env.REPLICATE_API_TOKEN}` } })).json()
  }
  if (p.status === 'failed') throw new Error('Prediction failed')
  return Array.isArray(p.output) ? p.output[0] : p.output
}
export const faceSwap = (src: string, tgt: string) =>
  run('9a4e3966a701bfa3c8cc3fc7a6d83e9ac9af8b40b3be5678fc8ff5f0af9bc5ae', { source_image:src, target_image:tgt })
export const generateAvatar = (img: string, style='anime') =>
  run('a4a8bafd6089e1716b06057c42b19378250d008b80fe87caa5cd36d40c1ebe90', { image:img, style, prompt:`${style} style avatar, high quality, cute kawaii` })
export const changeHair = (img: string, hairStyle: string, color: string) =>
  run('7762fd07cf82c948538e41f63ce34c5d8f5b7bdd4126e3a93a03a2fd0f3b258', { image:img, prompt:`person with ${hairStyle}, ${color} hair, same face, photorealistic`, negative_prompt:'different face, ugly' })
export const changeOutfit = (img: string, outfit: string) =>
  run('7762fd07cf82c948538e41f63ce34c5d8f5b7bdd4126e3a93a03a2fd0f3b258', { image:img, prompt:`person wearing ${outfit}, same face, fashion photo`, negative_prompt:'different face, naked, ugly' })
export const changeBackground = (img: string, prompt: string) =>
  run('a4a8bafd6089e1716b06057c42b19378250d008b80fe87caa5cd36d40c1ebe90', { image:img, prompt:`same person, background: ${prompt}, high quality` })

export async function removeBackgroundServer(imageUrl: string): Promise<string> {
  const res = await fetch('https://api.remove.bg/v1.0/removebg', {
    method:'POST',
    headers:{ 'X-Api-Key': process.env.REMOVE_BG_API_KEY!, 'Content-Type':'application/json' },
    body: JSON.stringify({ image_url: imageUrl, size:'auto' }),
  })
  if (!res.ok) throw new Error('Remove.bg error')
  const buf = await res.arrayBuffer()
  return `data:image/png;base64,${Buffer.from(buf).toString('base64')}`
}

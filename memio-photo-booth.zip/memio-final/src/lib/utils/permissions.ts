import type { Role, Permissions } from '@/types'
export const ROLE_PERMISSIONS: Record<Role, Permissions> = {
  user: {
    photos:{view:true,hide:false,delete:false},
    templates:{view:true,create:false,edit:false,delete:false},
    users:{view:false,warn:false,ban:false,delete:false,assign_role:false},
    analytics:{view_dashboard:false,view_stats:false,export:false},
    system:{audit_log:false,settings:false,backup:false},
  },
  moderator: {
    photos:{view:true,hide:true,delete:false},
    templates:{view:true,create:false,edit:false,delete:false},
    users:{view:true,warn:true,ban:true,delete:false,assign_role:false},
    analytics:{view_dashboard:true,view_stats:false,export:false},
    system:{audit_log:false,settings:false,backup:false},
  },
  editor: {
    photos:{view:true,hide:true,delete:false},
    templates:{view:true,create:true,edit:true,delete:true},
    users:{view:false,warn:false,ban:false,delete:false,assign_role:false},
    analytics:{view_dashboard:true,view_stats:true,export:true},
    system:{audit_log:false,settings:false,backup:false},
  },
  superadmin: {
    photos:{view:true,hide:true,delete:true},
    templates:{view:true,create:true,edit:true,delete:true},
    users:{view:true,warn:true,ban:true,delete:true,assign_role:true},
    analytics:{view_dashboard:true,view_stats:true,export:true},
    system:{audit_log:true,settings:true,backup:true},
  },
}
export function hasPermission<T extends keyof Permissions, A extends keyof Permissions[T]>(
  role: Role, resource: T, action: A
): boolean {
  return (ROLE_PERMISSIONS[role][resource] as Record<string,boolean>)[action as string] ?? false
}
export function isAdmin(role: Role): boolean {
  return ['moderator','editor','superadmin'].includes(role)
}

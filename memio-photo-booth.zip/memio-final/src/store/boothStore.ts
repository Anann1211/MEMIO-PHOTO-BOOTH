import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { Template, BoothSettings } from '@/types'

interface BoothState {
  selectedTemplate: Template | null
  capturedPhotos: string[]
  editedPhoto: string | null
  currentStep: number
  sessionId: string | null
  settings: BoothSettings
  isProcessing: boolean
  setTemplate: (t: Template) => void
  addPhoto: (url: string) => void
  removePhoto: (i: number) => void
  clearPhotos: () => void
  setEditedPhoto: (url: string | null) => void
  setStep: (s: number) => void
  setSessionId: (id: string) => void
  updateSettings: (s: Partial<BoothSettings>) => void
  setProcessing: (v: boolean) => void
  reset: () => void
}

export const useBoothStore = create<BoothState>()(
  persist(
    (set) => ({
      selectedTemplate: null, capturedPhotos: [], editedPhoto: null,
      currentStep: 1, sessionId: null, isProcessing: false,
      settings: { countdown:5, layout:'quad', flash_enabled:true, mirror_enabled:true },
      setTemplate: (t) => set({ selectedTemplate:t }),
      addPhoto: (url) => set((s) => ({ capturedPhotos:[...s.capturedPhotos, url] })),
      removePhoto: (i) => set((s) => ({ capturedPhotos: s.capturedPhotos.filter((_,idx) => idx!==i) })),
      clearPhotos: () => set({ capturedPhotos:[] }),
      setEditedPhoto: (url) => set({ editedPhoto:url }),
      setStep: (step) => set({ currentStep:step }),
      setSessionId: (id) => set({ sessionId:id }),
      updateSettings: (s) => set((prev) => ({ settings:{...prev.settings,...s} })),
      setProcessing: (v) => set({ isProcessing:v }),
      reset: () => set({ selectedTemplate:null, capturedPhotos:[], editedPhoto:null, currentStep:1, sessionId:null, isProcessing:false }),
    }),
    { name:'memio-booth', partialize:(s) => ({ settings:s.settings }) }
  )
)

'use client'
import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import toast from 'react-hot-toast'

export default function RegisterPage() {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  async function handleRegister(e: React.FormEvent) {
    e.preventDefault(); setLoading(true)
    const { error } = await supabase.auth.signUp({
      email, password,
      options: { data:{ full_name:name }, emailRedirectTo:`${location.origin}/api/auth/callback` },
    })
    if (error) toast.error(error.message)
    else { toast.success('Đăng ký thành công! Hãy kiểm tra email ✨'); router.push('/auth/dang-nhap') }
    setLoading(false)
  }

  async function handleGoogle() {
    await supabase.auth.signInWithOAuth({ provider:'google', options:{ redirectTo:`${location.origin}/api/auth/callback` } })
  }

  return (
    <div className="min-h-screen bg-animated flex items-center justify-center p-4">
      <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden">
        <div className="absolute top-20 right-10 w-64 h-64 rounded-full bg-memio-mint opacity-20 blur-3xl animate-float" />
        <div className="absolute bottom-20 left-10 w-80 h-80 rounded-full bg-memio-pink opacity-20 blur-3xl animate-float" style={{animationDelay:'2s'}} />
      </div>
      <div className="card-kawaii glass w-full max-w-md p-8">
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-memio-mint-dark to-memio-mint flex items-center justify-center mx-auto mb-3 shadow-kawaii animate-float">
            <span className="text-white font-display font-bold text-2xl">✨</span>
          </div>
          <h1 className="font-display font-extrabold text-2xl text-memio-brown dark:text-white">Tạo tài khoản miễn phí</h1>
          <p className="font-body text-sm text-memio-brown-light mt-1">Tham gia Memio Photo Booth ngay hôm nay!</p>
        </div>
        <button onClick={handleGoogle} className="btn-ghost w-full mb-5 py-3 flex items-center justify-center gap-3">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <path d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.716v2.259h2.908c1.702-1.567 2.684-3.875 2.684-6.615z" fill="#4285F4"/>
            <path d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332C2.438 15.983 5.482 18 9 18z" fill="#34A853"/>
            <path d="M3.964 10.71c-.18-.54-.282-1.117-.282-1.71s.102-1.17.282-1.71V4.958H.957C.347 6.173 0 7.548 0 9s.348 2.827.957 4.042l3.007-2.332z" fill="#FBBC05"/>
            <path d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0 5.482 0 2.438 2.017.957 4.958L3.964 6.29C4.672 4.163 6.656 3.58 9 3.58z" fill="#EA4335"/>
          </svg>
          Tiếp tục với Google
        </button>
        <div className="flex items-center gap-3 mb-5">
          <div className="flex-1 h-px bg-memio-pink/20"/>
          <span className="font-body text-xs text-memio-brown-light">hoặc</span>
          <div className="flex-1 h-px bg-memio-pink/20"/>
        </div>
        <form onSubmit={handleRegister} className="space-y-4">
          <div>
            <label className="font-body text-sm font-medium text-memio-brown dark:text-white block mb-1.5">Tên hiển thị</label>
            <input type="text" value={name} onChange={e=>setName(e.target.value)} placeholder="Tên dễ thương của bạn" required className="input-kawaii" />
          </div>
          <div>
            <label className="font-body text-sm font-medium text-memio-brown dark:text-white block mb-1.5">Email</label>
            <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="hello@memio.vn" required className="input-kawaii" />
          </div>
          <div>
            <label className="font-body text-sm font-medium text-memio-brown dark:text-white block mb-1.5">Mật khẩu</label>
            <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Ít nhất 8 ký tự" minLength={8} required className="input-kawaii" />
          </div>
          <button type="submit" disabled={loading} className="btn-primary w-full py-3.5">
            {loading ? 'Đang tạo tài khoản...' : 'Tạo tài khoản miễn phí ✨'}
          </button>
        </form>
        <p className="font-body text-center text-sm text-memio-brown-light mt-6">
          Đã có tài khoản?{' '}
          <Link href="/auth/dang-nhap" className="text-memio-pink-dark font-semibold hover:underline">Đăng nhập</Link>
        </p>
      </div>
    </div>
  )
}

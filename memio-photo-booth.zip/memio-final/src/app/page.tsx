import Link from 'next/link'

const FEATURES = [
  { icon:'🎥', title:'Webcam & Upload', desc:'Chụp trực tiếp qua webcam hoặc upload ảnh từ máy. Hỗ trợ GIF và Boomerang.' },
  { icon:'🤖', title:'AI Xóa nền', desc:'Tự động xóa nền chỉ 1 giây, chạy trực tiếp trên máy bạn — không gửi lên server.' },
  { icon:'🎭', title:'AI Face Swap', desc:'Hoán đổi khuôn mặt với bạn bè hoặc nhân vật yêu thích.' },
  { icon:'✨', title:'Beauty Filter AI', desc:'Làm đẹp, mịn da như app chuyên nghiệp. Chạy hoàn toàn trên trình duyệt.' },
  { icon:'💇', title:'Thay tóc & Trang phục', desc:'Thử kiểu tóc, màu tóc, và outfit mới chỉ một click.' },
  { icon:'🖼️', title:'Frame & Sticker', desc:'Hàng trăm khung ảnh và sticker Kawaii dễ thương.' },
  { icon:'🎨', title:'Filter màu sắc', desc:'Vintage, retro, pastel và nhiều phong cách khác.' },
  { icon:'📱', title:'QR Code & Tải về', desc:'Quét QR để tải ảnh ngay trên điện thoại.' },
  { icon:'🖨️', title:'In ảnh', desc:'In trực tiếp với bố cục photobooth chuyên nghiệp.' },
]

export default function LandingPage() {
  return (
    <main className="min-h-screen bg-animated overflow-x-hidden">
      <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 rounded-full bg-memio-pink opacity-20 blur-3xl animate-float" />
        <div className="absolute top-40 right-20 w-96 h-96 rounded-full bg-memio-mint opacity-20 blur-3xl animate-float" style={{animationDelay:'1.5s'}} />
        <div className="absolute bottom-40 left-1/2 w-80 h-80 rounded-full bg-memio-cream opacity-30 blur-3xl animate-float" style={{animationDelay:'3s'}} />
      </div>

      {/* Nav */}
      <nav className="glass sticky top-0 z-50 px-8 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-memio-pink-dark to-memio-pink flex items-center justify-center shadow-kawaii">
            <span className="text-white font-display font-bold">M</span>
          </div>
          <span className="font-display font-extrabold text-xl text-memio-brown dark:text-memio-pink">Memio</span>
        </div>
        <div className="flex gap-3">
          <Link href="/auth/dang-nhap"><button className="btn-ghost py-2 px-5 text-sm">Đăng nhập</button></Link>
          <Link href="/auth/dang-ky"><button className="btn-primary py-2 px-5 text-sm">Bắt đầu miễn phí ✨</button></Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="container mx-auto px-6 pt-24 pb-16 text-center max-w-4xl">
        <div className="inline-flex items-center gap-2 bg-white/70 dark:bg-white/10 backdrop-blur px-5 py-2 rounded-full mb-8 border border-memio-pink/30">
          <span className="animate-sparkle">✨</span>
          <span className="font-body text-sm text-memio-brown-light font-medium">Hoàn toàn miễn phí · AI mạnh mẽ · Kawaii</span>
          <span className="animate-sparkle" style={{animationDelay:'0.5s'}}>✨</span>
        </div>
        <h1 className="font-display font-extrabold text-5xl md:text-7xl text-memio-brown dark:text-white leading-tight mb-6">
          Photobooth{' '}
          <span className="bg-gradient-to-r from-memio-pink-dark via-memio-pink to-memio-mint bg-clip-text text-transparent">
            dễ thương nhất
          </span>
          <br />Việt Nam 🇻🇳
        </h1>
        <p className="font-body text-lg text-memio-brown-light dark:text-memio-pink max-w-2xl mx-auto mb-10 leading-relaxed">
          Chụp ảnh bằng webcam, chỉnh sửa với AI, thêm sticker Kawaii và tải về miễn phí. Không cần cài app!
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
          <Link href="/auth/dang-ky"><button className="btn-primary text-lg px-10 py-4 animate-pulse-pink">📸 Chụp ảnh ngay</button></Link>
          <Link href="/gallery/cong-khai"><button className="btn-ghost text-lg px-8 py-4">Xem gallery công khai</button></Link>
        </div>
        <div className="flex flex-wrap justify-center gap-6">
          {[['100%','Miễn phí'],['7+','Tính năng AI'],['20+','Template'],['∞','Lần chụp']].map(([v,l]) => (
            <div key={l} className="card-kawaii px-6 py-4 text-center">
              <div className="font-mono font-bold text-2xl text-memio-pink-dark">{v}</div>
              <div className="font-body text-xs text-memio-brown-light mt-1">{l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="container mx-auto px-6 py-16 max-w-6xl">
        <h2 className="font-display font-bold text-3xl text-center text-memio-brown dark:text-white mb-3">Tại sao chọn Memio?</h2>
        <p className="text-center text-memio-brown-light mb-12 max-w-xl mx-auto">Tất cả tính năng bạn cần để có những bức ảnh đẹp nhất</p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {FEATURES.map(f => (
            <div key={f.title} className="card-kawaii p-6 group cursor-default">
              <div className="text-4xl mb-3 group-hover:animate-sparkle transition-transform group-hover:scale-110">{f.icon}</div>
              <h3 className="font-display font-bold text-base text-memio-brown dark:text-white mb-2">{f.title}</h3>
              <p className="font-body text-sm text-memio-brown-light dark:text-memio-pink leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Steps */}
      <section className="container mx-auto px-6 py-16 max-w-4xl">
        <h2 className="font-display font-bold text-3xl text-center text-memio-brown dark:text-white mb-12">3 bước đơn giản</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {[['📸','Chọn template','Chọn bố cục yêu thích: 1 ô, 4 ô, hay dạng strip.'],['🎨','Chụp & Chỉnh sửa','Chụp ảnh, thêm AI effects, sticker và filter dễ thương.'],['💾','Lưu & Tải về','Download ảnh hoặc quét QR để lưu trên điện thoại.']].map(([icon,title,desc],i) => (
            <div key={title} className="text-center">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-memio-pink-dark to-memio-pink flex items-center justify-center mx-auto mb-4 shadow-kawaii">
                <span className="font-mono font-bold text-xl text-white">{i+1}</span>
              </div>
              <div className="text-3xl mb-3">{icon}</div>
              <h3 className="font-display font-bold text-base text-memio-brown dark:text-white mb-2">{title}</h3>
              <p className="font-body text-sm text-memio-brown-light dark:text-memio-pink">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="container mx-auto px-6 py-20 max-w-3xl">
        <div className="card-kawaii p-12 text-center bg-gradient-to-br from-memio-pink/15 to-memio-mint/15">
          <h2 className="font-display font-extrabold text-4xl text-memio-brown dark:text-white mb-4">Sẵn sàng chưa? 📸</h2>
          <p className="font-body text-memio-brown-light mb-8">Tạo tài khoản miễn phí, không cần thẻ tín dụng</p>
          <Link href="/auth/dang-ky"><button className="btn-primary text-xl px-12 py-5">Tạo tài khoản miễn phí ✨</button></Link>
        </div>
      </section>

      <footer className="glass border-t border-memio-pink/20 py-8 text-center">
        <p className="font-body text-sm text-memio-brown-light">© 2026 Memio Photo Booth · Làm với ♡ tại Việt Nam 🇻🇳</p>
      </footer>
    </main>
  )
}

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { hasPermission } from '@/lib/utils/permissions'
export async function GET(req: NextRequest) {
  const supabase = createClient()
  const { data:{ user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error:'Unauthorized' },{status:401})
  const { data:profile } = await supabase.from('profiles').select('role').eq('id',user.id).single()
  if (!profile || !hasPermission(profile.role,'users','view'))
    return NextResponse.json({ error:'Forbidden' },{status:403})
  const page = Number(new URL(req.url).searchParams.get('page')??1)
  const from = (page-1)*20
  const { data,count } = await supabase.from('profiles').select('*',{count:'exact'}).order('created_at',{ascending:false}).range(from,from+19)
  return NextResponse.json({ users:data, total:count, page })
}
export async function PATCH(req: NextRequest) {
  const supabase = createClient()
  const { data:{ user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error:'Unauthorized' },{status:401})
  const { data:profile } = await supabase.from('profiles').select('role').eq('id',user.id).single()
  if (!profile) return NextResponse.json({ error:'Forbidden' },{status:403})
  const { target_id, action, role } = await req.json()
  if (action==='assign_role' && !hasPermission(profile.role,'users','assign_role'))
    return NextResponse.json({ error:'Forbidden' },{status:403})
  if (action==='ban' && !hasPermission(profile.role,'users','ban'))
    return NextResponse.json({ error:'Forbidden' },{status:403})
  const update: Record<string,unknown> = {}
  if (action==='assign_role') update.role = role
  if (action==='ban') update.is_active = false
  if (action==='unban') update.is_active = true
  await supabase.from('profiles').update(update).eq('id',target_id)
  await supabase.from('audit_logs').insert({ admin_user_id:user.id, action:`${action}_user`, entity_type:'user', entity_id:target_id, changes:update })
  return NextResponse.json({ success:true })
}

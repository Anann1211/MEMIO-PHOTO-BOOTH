import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { hasPermission } from '@/lib/utils/permissions'
export async function GET() {
  const supabase = createClient()
  const { data:{ user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error:'Unauthorized' },{status:401})
  const { data:profile } = await supabase.from('profiles').select('role').eq('id',user.id).single()
  if (!profile || !hasPermission(profile.role,'analytics','view_dashboard'))
    return NextResponse.json({ error:'Forbidden' },{status:403})
  const [{ count:totalUsers },{ count:totalPhotos },{ count:todaySessions },{ count:publicPhotos }] = await Promise.all([
    supabase.from('profiles').select('*',{count:'exact',head:true}),
    supabase.from('photos').select('*',{count:'exact',head:true}),
    supabase.from('sessions').select('*',{count:'exact',head:true}).gte('started_at',new Date(Date.now()-86400000).toISOString()),
    supabase.from('photos').select('*',{count:'exact',head:true}).eq('is_public',true),
  ])
  return NextResponse.json({ totalUsers,totalPhotos,todaySessions,publicPhotos })
}

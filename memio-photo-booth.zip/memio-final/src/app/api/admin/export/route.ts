import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { hasPermission } from '@/lib/utils/permissions'
import * as XLSX from 'xlsx'
export async function GET() {
  const supabase = createClient()
  const { data:{ user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error:'Unauthorized' },{status:401})
  const { data:profile } = await supabase.from('profiles').select('role').eq('id',user.id).single()
  if (!profile || !hasPermission(profile.role,'analytics','export'))
    return NextResponse.json({ error:'Forbidden' },{status:403})
  const { data:users } = await supabase.from('profiles').select('id,email,display_name,role,is_active,created_at')
  const { data:photos } = await supabase.from('photos').select('id,user_id,is_public,created_at')
  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(users??[]), 'Users')
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(photos??[]), 'Photos')
  const buf = XLSX.write(wb, { type:'buffer', bookType:'xlsx' })
  return new NextResponse(buf, { headers:{
    'Content-Type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'Content-Disposition':`attachment; filename="memio-report-${Date.now()}.xlsx"`,
  }})
}

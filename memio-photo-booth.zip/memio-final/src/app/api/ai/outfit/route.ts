import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { changeOutfit } from '@/lib/ai/replicate'
export async function POST(req: NextRequest) {
  const supabase = createClient()
  const { data:{ user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error:'Unauthorized' },{status:401})
  const { image_url, outfit_description } = await req.json()
  try { return NextResponse.json({ success:true, result_url: await changeOutfit(image_url, outfit_description) }) }
  catch { return NextResponse.json({ error:'Outfit change failed' },{status:500}) }
}

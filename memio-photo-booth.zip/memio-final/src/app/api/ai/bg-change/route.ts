import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { changeBackground } from '@/lib/ai/replicate'
export async function POST(req: NextRequest) {
  const supabase = createClient()
  const { data:{ user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error:'Unauthorized' },{status:401})
  const { image_url, bg_prompt } = await req.json()
  try { return NextResponse.json({ success:true, result_url: await changeBackground(image_url, bg_prompt) }) }
  catch { return NextResponse.json({ error:'BG change failed' },{status:500}) }
}

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { generateAvatar } from '@/lib/ai/replicate'
export async function POST(req: NextRequest) {
  const supabase = createClient()
  const { data:{ user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error:'Unauthorized' },{status:401})
  const { image_url, style='anime' } = await req.json()
  try { return NextResponse.json({ success:true, result_url: await generateAvatar(image_url, style) }) }
  catch { return NextResponse.json({ error:'Avatar failed' },{status:500}) }
}

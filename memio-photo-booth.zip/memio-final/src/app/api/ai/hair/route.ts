import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { changeHair } from '@/lib/ai/replicate'
export async function POST(req: NextRequest) {
  const supabase = createClient()
  const { data:{ user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error:'Unauthorized' },{status:401})
  const { image_url, hair_style, color } = await req.json()
  try { return NextResponse.json({ success:true, result_url: await changeHair(image_url, hair_style, color) }) }
  catch { return NextResponse.json({ error:'Hair change failed' },{status:500}) }
}

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { removeBackgroundServer } from '@/lib/ai/removeBackground'
export async function POST(req: NextRequest) {
  const supabase = createClient()
  const { data:{ user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error:'Unauthorized' },{status:401})
  const { image_url } = await req.json()
  try { return NextResponse.json({ success:true, result_url: await removeBackgroundServer(image_url) }) }
  catch { return NextResponse.json({ error:'AI failed' },{status:500}) }
}

import type { Metadata } from 'next'
import { Nunito, Be_Vietnam_Pro, Space_Grotesk } from 'next/font/google'
import { Toaster } from 'react-hot-toast'
import './globals.css'

const nunito = Nunito({ subsets:['latin','vietnamese'], variable:'--font-display', weight:['400','600','700','800'] })
const beVietnam = Be_Vietnam_Pro({ subsets:['latin','vietnamese'], variable:'--font-body', weight:['300','400','500','600'] })
const spaceGrotesk = Space_Grotesk({ subsets:['latin'], variable:'--font-mono', weight:['400','500','700'] })

export const metadata: Metadata = {
  title: 'Memio Photo Booth – Chụp ảnh dễ thương, miễn phí',
  description: 'Photobooth online miễn phí với AI xóa nền, đổi tóc, thay trang phục, filter làm đẹp. Dành cho mọi lứa tuổi tại Việt Nam.',
  keywords: ['photobooth','chụp ảnh online','memio','kawaii','AI photo'],
  openGraph: { title:'Memio Photo Booth', description:'Chụp ảnh dễ thương, AI mạnh mẽ, miễn phí!', locale:'vi_VN', type:'website' },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="vi" suppressHydrationWarning>
      <body className={`${nunito.variable} ${beVietnam.variable} ${spaceGrotesk.variable} font-body antialiased`}>
        {children}
        <Toaster position="top-center" toastOptions={{
          style:{ background:'var(--color-surface)', color:'var(--color-text)', borderRadius:'14px', boxShadow:'0 8px 32px rgba(255,184,198,0.25)' },
          success:{ iconTheme:{ primary:'#7DD8C0', secondary:'#fff' } },
          error:{ iconTheme:{ primary:'#FF8FAB', secondary:'#fff' } },
        }} />
      </body>
    </html>
  )
}

'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import toast from 'react-hot-toast'

const NAV = [
  { href:'/admin/nguoi-dung', icon:'👥', label:'Người dùng', roles:['moderator','editor','superadmin'] },
  { href:'/admin/anh', icon:'🖼️', label:'Quản lý ảnh', roles:['moderator','editor','superadmin'] },
  { href:'/admin/template', icon:'🎨', label:'Template & Nội dung', roles:['editor','superadmin'] },
  { href:'/admin/thong-ke', icon:'📊', label:'Thống kê', roles:['editor','superadmin'] },
  { href:'/admin/audit-log', icon:'📋', label:'Audit Log', roles:['superadmin'] },
]

export default function AdminDashboard() {
  const [stats, setStats] = useState<Record<string,number>|null>(null)
  const [role, setRole] = useState('')
  const [loading, setLoading] = useState(true)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    async function load() {
      const { data:{ user } } = await supabase.auth.getUser()
      if (!user) { router.push('/auth/dang-nhap'); return }
      const { data:p } = await supabase.from('profiles').select('role').eq('id',user.id).single()
      if (!p || !['moderator','editor','superadmin'].includes(p.role)) {
        toast.error('Bạn không có quyền truy cập'); router.push('/'); return
      }
      setRole(p.role)
      const r = await fetch('/api/admin/dashboard')
      if (r.ok) setStats(await r.json())
      setLoading(false)
    }
    load()
  }, [])

  if (loading) return (
    <div className="min-h-screen bg-animated flex items-center justify-center">
      <div className="text-center">
        <div className="w-12 h-12 rounded-full border-4 border-memio-pink border-t-transparent animate-spin mx-auto mb-4"/>
        <p className="font-body text-memio-brown-light">Đang tải...</p>
      </div>
    </div>
  )

  const cards = [
    { label:'Tổng người dùng', value:stats?.totalUsers??0, icon:'👥', from:'from-memio-pink/20', to:'to-memio-pink/5' },
    { label:'Tổng ảnh', value:stats?.totalPhotos??0, icon:'📸', from:'from-memio-mint/20', to:'to-memio-mint/5' },
    { label:'Phiên hôm nay', value:stats?.todaySessions??0, icon:'🎯', from:'from-memio-cream/40', to:'to-memio-cream/10' },
    { label:'Ảnh công khai', value:stats?.publicPhotos??0, icon:'🌐', from:'from-memio-sparkle/20', to:'to-memio-sparkle/5' },
  ]

  return (
    <div className="min-h-screen bg-animated">
      <nav className="glass sticky top-0 z-50 px-6 py-4 flex items-center justify-between border-b border-memio-pink/20">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-memio-pink-dark to-memio-pink flex items-center justify-center">
            <span className="text-white font-display font-bold text-sm">M</span>
          </div>
          <span className="font-display font-bold text-memio-brown dark:text-white">Admin Panel</span>
          <span className="px-2 py-0.5 bg-memio-pink/20 text-memio-pink-dark rounded-full text-xs capitalize">{role}</span>
        </div>
        <div className="flex gap-2">
          <a href="/" className="btn-ghost text-sm py-1.5 px-4">← Trang chủ</a>
          <button onClick={async()=>{await supabase.auth.signOut();router.push('/')}} className="btn-ghost text-sm py-1.5 px-4">Đăng xuất</button>
        </div>
      </nav>

      <div className="container mx-auto px-6 py-8 max-w-7xl">
        <div className="flex gap-8">
          <aside className="w-52 shrink-0">
            <nav className="card-kawaii p-3 space-y-1">
              {NAV.filter(n=>n.roles.includes(role)).map(n=>(
                <a key={n.href} href={n.href} className="flex items-center gap-3 px-3 py-2.5 rounded-xl font-body text-sm text-memio-brown dark:text-white hover:bg-memio-pink/10 transition">
                  <span>{n.icon}</span>{n.label}
                </a>
              ))}
            </nav>
          </aside>

          <main className="flex-1">
            <h1 className="font-display font-bold text-2xl text-memio-brown dark:text-white mb-6">Tổng quan hệ thống</h1>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              {cards.map(c=>(
                <div key={c.label} className={`card-kawaii p-5 bg-gradient-to-br ${c.from} ${c.to}`}>
                  <div className="text-3xl mb-2">{c.icon}</div>
                  <div className="font-mono font-bold text-2xl text-memio-brown dark:text-white">{c.value.toLocaleString()}</div>
                  <div className="font-body text-xs text-memio-brown-light mt-1">{c.label}</div>
                </div>
              ))}
            </div>
            <div className="card-kawaii p-6">
              <h2 className="font-display font-semibold text-lg text-memio-brown dark:text-white mb-4">Thao tác nhanh</h2>
              <div className="flex flex-wrap gap-3">
                <a href="/admin/nguoi-dung" className="btn-primary text-sm py-2 px-5">Quản lý người dùng</a>
                <a href="/admin/anh" className="btn-secondary text-sm py-2 px-5">Kiểm duyệt ảnh</a>
                {['editor','superadmin'].includes(role) && (
                  <button onClick={()=>fetch('/api/admin/export').then(r=>r.blob()).then(b=>{
                    const a=document.createElement('a'); a.href=URL.createObjectURL(b);
                    a.download=`memio-report-${Date.now()}.xlsx`; a.click(); toast.success('Đã xuất báo cáo!')
                  })} className="btn-ghost text-sm py-2 px-5">📊 Xuất Excel</button>
                )}
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  )
}

'use client'
import { useRouter } from 'next/navigation'
import { useBoothStore } from '@/store/boothStore'
import { WebcamCapture } from '@/components/booth/WebcamCapture'
import toast from 'react-hot-toast'

const MAX_PHOTOS: Record<string,number> = { single:1, double:2, quad:4, strip_v:4, strip_h:4, grid:6 }

export default function CaptureePage() {
  const router = useRouter()
  const { capturedPhotos, addPhoto, removePhoto, clearPhotos, selectedTemplate, setStep } = useBoothStore()
  const maxPhotos = MAX_PHOTOS[selectedTemplate?.layout_type ?? 'quad'] ?? 4

  function handleCapture(url: string) {
    if (capturedPhotos.length >= maxPhotos) { toast.error('Đã đủ số ảnh!'); return }
    addPhoto(url)
    if (capturedPhotos.length + 1 >= maxPhotos) toast.success(`Đã chụp đủ ${maxPhotos} ảnh! ✨`)
  }

  function handleNext() {
    if (capturedPhotos.length === 0) { toast.error('Hãy chụp ít nhất 1 ảnh!'); return }
    setStep(7); router.push('/booth/chinh-sua')
  }

  return (
    <div className="min-h-screen bg-animated">
      <div className="container mx-auto px-4 py-8 max-w-5xl">
        <div className="flex items-center gap-2 mb-8">
          {Array.from({length:10},(_,i)=>(
            <div key={i} className={`h-1.5 flex-1 rounded-full ${i<4?'bg-memio-pink':'bg-memio-pink/20'}`}/>
          ))}
          <span className="font-mono text-xs text-memio-brown-light ml-2">2-4/10</span>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          <div className="lg:col-span-3">
            <h1 className="font-display font-bold text-2xl text-memio-brown dark:text-white mb-1">Vào vị trí và tạo dáng! 🎭</h1>
            <p className="font-body text-sm text-memio-brown-light mb-5">Cần {maxPhotos} ảnh · Đã chụp {capturedPhotos.length}/{maxPhotos}</p>
            <WebcamCapture onCapture={handleCapture} />
          </div>
          <div className="lg:col-span-2">
            <h2 className="font-display font-semibold text-lg text-memio-brown dark:text-white mb-4">Ảnh đã chụp</h2>
            <div className="grid grid-cols-2 gap-3 mb-5">
              {Array.from({length:maxPhotos},(_,i) => (
                <div key={i} className="relative aspect-[3/4] rounded-xl overflow-hidden border-2 border-dashed border-memio-pink/30 bg-memio-pink/5">
                  {capturedPhotos[i] ? (
                    <>
                      <img src={capturedPhotos[i]} alt={`Ảnh ${i+1}`} className="w-full h-full object-cover"/>
                      <button onClick={()=>removePhoto(i)} className="absolute top-1 right-1 w-6 h-6 bg-memio-pink-dark text-white rounded-full text-xs hover:bg-red-500 transition flex items-center justify-center">×</button>
                    </>
                  ) : (
                    <div className="w-full h-full flex items-center justify-center"><span className="text-2xl opacity-30">{i+1}</span></div>
                  )}
                </div>
              ))}
            </div>
            <div className="space-y-3">
              <button onClick={handleNext} disabled={capturedPhotos.length===0} className="btn-primary w-full py-3.5 disabled:opacity-50">Tiếp theo ✨</button>
              <button onClick={clearPhotos} className="btn-ghost w-full py-3 text-sm">Chụp lại tất cả</button>
              <button onClick={()=>router.back()} className="w-full text-center font-body text-xs text-memio-brown-light hover:text-memio-pink transition py-2">← Quay lại chọn template</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

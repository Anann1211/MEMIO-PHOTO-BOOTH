'use client'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { useBoothStore } from '@/store/boothStore'
import type { Template } from '@/types'

const LAYOUT_LABELS: Record<string,string> = {
  single:'1 ảnh', double:'2 ảnh', quad:'4 ảnh (Classic)', strip_v:'Strip dọc', strip_h:'Strip ngang', grid:'Grid 6 ảnh'
}
const LAYOUT_ICONS: Record<string,string> = {
  single:'⬜', double:'⬜⬜', quad:'⊞', strip_v:'☰', strip_h:'☰', grid:'⊟'
}

export default function ChooseTemplatePage() {
  const [templates, setTemplates] = useState<Template[]>([])
  const [loading, setLoading] = useState(true)
  const { selectedTemplate, setTemplate, settings, updateSettings } = useBoothStore()
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    supabase.from('templates').select('*').eq('is_active',true).order('usage_count',{ascending:false}).then(({ data }) => {
      if (data) setTemplates(data)
      setLoading(false)
    })
  }, [])

  function handleSelect(t: Template) { setTemplate(t) }

  function handleNext() {
    if (!selectedTemplate) return
    router.push('/booth/chup-anh')
  }

  return (
    <div className="min-h-screen bg-animated">
      <div className="container mx-auto px-6 py-8 max-w-4xl">
        {/* Progress */}
        <div className="flex items-center gap-2 mb-8">
          {Array.from({length:10},(_,i)=>(
            <div key={i} className={`h-1.5 flex-1 rounded-full transition-all ${i<1?'bg-memio-pink':'bg-memio-pink/20'}`}/>
          ))}
          <span className="font-mono text-xs text-memio-brown-light ml-2">1/10</span>
        </div>

        <div className="text-center mb-10">
          <h1 className="font-display font-extrabold text-3xl text-memio-brown dark:text-white mb-2">
            Chọn kiểu bố cục ảnh 🖼️
          </h1>
          <p className="font-body text-memio-brown-light">Chọn layout phù hợp với phong cách của bạn</p>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {Array.from({length:6}).map((_,i) => <div key={i} className="card-kawaii h-40 shimmer"/>)}
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
            {templates.map(t => (
              <button
                key={t.id}
                onClick={() => handleSelect(t)}
                className={`card-kawaii p-6 text-center transition-all cursor-pointer border-2 ${
                  selectedTemplate?.id===t.id
                    ? 'border-memio-pink shadow-kawaii-lg scale-105'
                    : 'border-transparent hover:border-memio-pink/40'
                }`}
              >
                <div className="text-4xl mb-3">{LAYOUT_ICONS[t.layout_type]}</div>
                <div className="font-display font-bold text-sm text-memio-brown dark:text-white">{t.name}</div>
                <div className="font-body text-xs text-memio-brown-light mt-1">{LAYOUT_LABELS[t.layout_type]}</div>
                {selectedTemplate?.id===t.id && (
                  <div className="mt-2 inline-flex items-center gap-1 bg-memio-pink text-memio-brown text-xs font-body px-2 py-0.5 rounded-full">
                    ✓ Đã chọn
                  </div>
                )}
              </button>
            ))}
          </div>
        )}

        {/* Countdown setting */}
        <div className="card-kawaii p-5 mb-6">
          <h3 className="font-display font-semibold text-memio-brown dark:text-white mb-3">Đếm ngược trước khi chụp</h3>
          <div className="flex gap-3">
            {[3,5,10].map(s => (
              <button
                key={s}
                onClick={() => updateSettings({ countdown:s })}
                className={`px-5 py-2 rounded-full font-mono font-bold text-sm transition-all ${
                  settings.countdown===s
                    ? 'bg-memio-pink text-memio-brown shadow-kawaii'
                    : 'btn-ghost'
                }`}
              >{s}s</button>
            ))}
          </div>
        </div>

        <button
          onClick={handleNext}
          disabled={!selectedTemplate}
          className="btn-primary w-full py-4 text-lg disabled:opacity-50"
        >
          Tiếp theo: Vào chụp ảnh 📸
        </button>
      </div>
    </div>
  )
}

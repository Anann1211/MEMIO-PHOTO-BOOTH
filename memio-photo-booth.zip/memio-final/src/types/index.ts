export type Role = 'user' | 'moderator' | 'editor' | 'superadmin'

export interface User {
  id: string; email: string; display_name: string
  avatar_url?: string; role: Role; is_active: boolean; created_at: string
}
export interface Photo {
  id: string; user_id: string; session_id: string; template_id?: string
  storage_url: string; thumbnail_url: string; qr_code_url?: string
  is_public: boolean; ai_params?: Record<string,unknown>; created_at: string
}
export interface Template {
  id: string; name: string
  layout_type: 'single'|'double'|'quad'|'strip_v'|'strip_h'|'grid'
  preview_url: string; is_active: boolean; usage_count: number; created_at: string
}
export interface Frame { id:string; template_id?:string; image_url:string; category:string; is_active:boolean }
export interface Sticker { id:string; name:string; image_url:string; category:string; is_active:boolean }
export interface Filter { id:string; name:string; css_filter:string; preview_url:string; category:string; is_active:boolean }
export interface GalleryItem { id:string; user_id:string; photo_id:string; is_public:boolean; saved_at:string; photo?:Photo }
export interface Permissions {
  photos: { view:boolean; hide:boolean; delete:boolean }
  templates: { view:boolean; create:boolean; edit:boolean; delete:boolean }
  users: { view:boolean; warn:boolean; ban:boolean; delete:boolean; assign_role:boolean }
  analytics: { view_dashboard:boolean; view_stats:boolean; export:boolean }
  system: { audit_log:boolean; settings:boolean; backup:boolean }
}
export interface AuditLog { id:string; admin_user_id:string; action:string; entity_type:string; entity_id:string; changes?:Record<string,unknown>; created_at:string }
export type CountdownDuration = 3|5|10|number
export interface BoothSettings { countdown:CountdownDuration; layout:Template['layout_type']; flash_enabled:boolean; mirror_enabled:boolean }
export type AIFeature = 'remove_bg'|'face_swap'|'avatar'|'hair_change'|'outfit_change'|'bg_change'|'beauty_filter'

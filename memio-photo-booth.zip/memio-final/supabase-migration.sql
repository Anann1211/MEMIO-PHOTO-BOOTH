-- =============================================
-- MEMIO PHOTO BOOTH — DATABASE MIGRATION v1.0
-- Chạy file này trong Supabase SQL Editor
-- =============================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Profiles
CREATE TABLE IF NOT EXISTS profiles (
  id           UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email        TEXT UNIQUE NOT NULL,
  display_name TEXT NOT NULL DEFAULT 'Memio User',
  avatar_url   TEXT,
  role         TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user','moderator','editor','superadmin')),
  is_active    BOOLEAN NOT NULL DEFAULT true,
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  updated_at   TIMESTAMPTZ DEFAULT NOW()
);

-- Sessions
CREATE TABLE IF NOT EXISTS sessions (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  status      TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','completed','abandoned')),
  photo_count INTEGER NOT NULL DEFAULT 0,
  started_at  TIMESTAMPTZ DEFAULT NOW(),
  ended_at    TIMESTAMPTZ
);

-- Templates
CREATE TABLE IF NOT EXISTS templates (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name         TEXT NOT NULL,
  layout_type  TEXT NOT NULL CHECK (layout_type IN ('single','double','quad','strip_v','strip_h','grid')),
  preview_url  TEXT NOT NULL DEFAULT '/assets/templates/default.png',
  is_active    BOOLEAN NOT NULL DEFAULT true,
  usage_count  INTEGER NOT NULL DEFAULT 0,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- Photos
CREATE TABLE IF NOT EXISTS photos (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  session_id    UUID NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  template_id   UUID REFERENCES templates(id),
  storage_url   TEXT NOT NULL,
  thumbnail_url TEXT NOT NULL,
  qr_code_url   TEXT,
  is_public     BOOLEAN NOT NULL DEFAULT false,
  ai_params     JSONB,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- Frames
CREATE TABLE IF NOT EXISTS frames (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  template_id UUID REFERENCES templates(id),
  image_url   TEXT NOT NULL,
  category    TEXT NOT NULL DEFAULT 'general',
  is_active   BOOLEAN NOT NULL DEFAULT true
);

-- Stickers
CREATE TABLE IF NOT EXISTS stickers (
  id        UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name      TEXT NOT NULL,
  image_url TEXT NOT NULL,
  category  TEXT NOT NULL DEFAULT 'kawaii',
  is_active BOOLEAN NOT NULL DEFAULT true
);

-- Filters
CREATE TABLE IF NOT EXISTS filters (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name        TEXT NOT NULL,
  css_filter  TEXT NOT NULL,
  preview_url TEXT NOT NULL DEFAULT '/assets/filters/default.jpg',
  category    TEXT NOT NULL DEFAULT 'general',
  is_active   BOOLEAN NOT NULL DEFAULT true
);

-- Gallery items
CREATE TABLE IF NOT EXISTS gallery_items (
  id        UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id   UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  photo_id  UUID NOT NULL REFERENCES photos(id) ON DELETE CASCADE,
  is_public BOOLEAN NOT NULL DEFAULT false,
  saved_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, photo_id)
);

-- Audit logs
CREATE TABLE IF NOT EXISTS audit_logs (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  admin_user_id UUID NOT NULL REFERENCES profiles(id),
  action        TEXT NOT NULL,
  entity_type   TEXT NOT NULL,
  entity_id     UUID,
  changes       JSONB,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ============================
-- RLS (Row Level Security)
-- ============================
ALTER TABLE profiles      ENABLE ROW LEVEL SECURITY;
ALTER TABLE sessions      ENABLE ROW LEVEL SECURITY;
ALTER TABLE photos        ENABLE ROW LEVEL SECURITY;
ALTER TABLE gallery_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs    ENABLE ROW LEVEL SECURITY;
ALTER TABLE templates     ENABLE ROW LEVEL SECURITY;
ALTER TABLE frames        ENABLE ROW LEVEL SECURITY;
ALTER TABLE stickers      ENABLE ROW LEVEL SECURITY;
ALTER TABLE filters       ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "users_own_profile" ON profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "admins_view_all_profiles" ON profiles FOR SELECT USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('moderator','editor','superadmin'))
);
CREATE POLICY "users_update_own" ON profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "admins_update_profiles" ON profiles FOR UPDATE USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('editor','superadmin'))
);

-- Sessions
CREATE POLICY "own_sessions" ON sessions FOR ALL USING (auth.uid() = user_id);

-- Photos
CREATE POLICY "own_photos" ON photos FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "public_photos" ON photos FOR SELECT USING (is_public = true AND auth.role() = 'authenticated');
CREATE POLICY "admins_manage_photos" ON photos FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('moderator','editor','superadmin'))
);

-- Gallery
CREATE POLICY "own_gallery" ON gallery_items FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "public_gallery" ON gallery_items FOR SELECT USING (is_public = true AND auth.role() = 'authenticated');

-- Audit logs
CREATE POLICY "superadmin_audit" ON audit_logs FOR SELECT USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'superadmin')
);
CREATE POLICY "admins_insert_audit" ON audit_logs FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('moderator','editor','superadmin'))
);

-- Content (templates, frames, stickers, filters)
CREATE POLICY "auth_read_templates" ON templates FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "editor_manage_templates" ON templates FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('editor','superadmin'))
);
CREATE POLICY "auth_read_frames" ON frames FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "editor_manage_frames" ON frames FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('editor','superadmin'))
);
CREATE POLICY "auth_read_stickers" ON stickers FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "editor_manage_stickers" ON stickers FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('editor','superadmin'))
);
CREATE POLICY "auth_read_filters" ON filters FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "editor_manage_filters" ON filters FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('editor','superadmin'))
);

-- ============================
-- TRIGGER: Auto-create profile
-- ============================
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, email, display_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email,'@',1))
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ============================
-- SEED DATA
-- ============================
INSERT INTO templates (name, layout_type) VALUES
  ('Classic 4-cut',    'quad'),
  ('Single Shot',      'single'),
  ('Double Frame',     'double'),
  ('Vertical Strip',   'strip_v'),
  ('Horizontal Strip', 'strip_h'),
  ('Photo Grid',       'grid')
ON CONFLICT DO NOTHING;

INSERT INTO filters (name, css_filter, category) VALUES
  ('Bình thường',  'none',                                                         'basic'),
  ('Ấm áp',       'sepia(0.3) saturate(1.2) brightness(1.05)',                    'vintage'),
  ('Vintage',     'sepia(0.6) contrast(1.1) brightness(0.9)',                     'vintage'),
  ('Đen trắng',   'grayscale(1)',                                                  'classic'),
  ('Pastel hồng', 'saturate(0.8) brightness(1.1) hue-rotate(330deg)',             'kawaii'),
  ('Mint tươi',   'saturate(1.2) hue-rotate(150deg) brightness(1.05)',            'kawaii'),
  ('Lạnh',        'saturate(0.9) hue-rotate(200deg) brightness(0.95)',            'mood'),
  ('Vàng nắng',   'sepia(0.2) saturate(1.4) brightness(1.1) hue-rotate(15deg)',  'mood'),
  ('Dreamy',      'saturate(0.7) brightness(1.15) contrast(0.9) blur(0px)',       'kawaii'),
  ('Neon',        'saturate(2) contrast(1.2) hue-rotate(30deg)',                  'bold')
ON CONFLICT DO NOTHING;

-- Set first user as superadmin (optional — run manually after first signup)
-- UPDATE profiles SET role = 'superadmin' WHERE email = 'your-email@example.com';

import type { Config } from 'tailwindcss'
const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        memio: {
          pink: '#FFB8C6', 'pink-dark': '#FF8FAB',
          mint: '#B8EDE0', 'mint-dark': '#7DD8C0',
          cream: '#FFF0B3', brown: '#3D1F0D', 'brown-light': '#7A4A2A',
          sparkle: '#FFD966', 'bg-light': '#FFF5F7', 'bg-dark': '#1A1025',
        },
      },
      fontFamily: {
        display: ['Nunito','sans-serif'],
        body: ['Be Vietnam Pro','sans-serif'],
        mono: ['Space Grotesk','monospace'],
      },
      borderRadius: { card: '20px', input: '14px', pill: '9999px' },
      boxShadow: {
        kawaii: '0 8px 32px rgba(255,184,198,0.25)',
        'kawaii-lg': '0 16px 48px rgba(255,184,198,0.35)',
      },
      animation: {
        float: 'float 3s ease-in-out infinite',
        sparkle: 'sparkle 1.5s ease-in-out infinite',
        countdown: 'countdown 1s ease-in-out',
        flash: 'flash 0.4s ease-out forwards',
        shimmer: 'shimmer 1.5s infinite',
        'pulse-pink': 'pulse-pink 2s ease-in-out infinite',
        'bg-shift': 'bg-shift 8s ease-in-out infinite',
      },
      keyframes: {
        float: { '0%,100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(-10px)' } },
        sparkle: { '0%,100%': { opacity:'1',transform:'scale(1)' }, '50%': { opacity:'0.6',transform:'scale(1.2)' } },
        countdown: { '0%': { transform:'scale(1.5)',opacity:'0' }, '100%': { transform:'scale(1)',opacity:'1' } },
        flash: { '0%': { opacity:'1' }, '100%': { opacity:'0' } },
        shimmer: { '0%': { backgroundPosition:'-200% 0' }, '100%': { backgroundPosition:'200% 0' } },
        'pulse-pink': { '0%,100%': { boxShadow:'0 0 0 0 rgba(255,184,198,0.4)' }, '50%': { boxShadow:'0 0 0 12px rgba(255,184,198,0)' } },
        'bg-shift': { '0%,100%': { backgroundPosition:'0% 50%' }, '50%': { backgroundPosition:'100% 50%' } },
      },
    },
  },
  plugins: [],
}
export default config
